import math

# Function to generate G-code for a square
def generate_square_gcode(length, feed_rate):
    gcode = "G1 F" + str(feed_rate) + "\n"
    gcode += "G1 X" + str(length) + " Y0\n"
    gcode += "G1 X" + str(length) + " Y" + str(length) + "\n"
    gcode += "G1 X0 Y" + str(length) + "\n"
    gcode += "G1 X0 Y0\n"
    return gcode

# Function to generate G-code for a circle
def generate_circle_gcode(radius, feed_rate):
    gcode = "G1 F" + str(feed_rate) + "\n"
    num_segments = 20
    for i in range(num_segments):
        angle = i * 2 * math.pi / num_segments
        x = radius * math.cos(angle)
        y = radius * math.sin(angle)
        gcode += "G1 X" + str(x) + " Y" + str(y) + "\n"
    return gcode

